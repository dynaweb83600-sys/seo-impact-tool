<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ReportItem;
use Illuminate\Http\Request;
use App\Services\Content\OpenAIResponsesClient;

class ReportItemBacklinksController extends Controller
{
	public function show(ReportItem $item, OpenAIResponsesClient $openai)
	{
		//$authority = (int) $item->authority_score;      // ex: 29
		$authority = (int) ($item->authority_score ?? 0);

		if ($authority <= 0) {
			// fallback : calcul simple à partir des données dispo
			$rd  = (int) ($item->linking_domains ?? 0);
			$kw  = (int) ($item->organic_keywords ?? 0);
			$etv = (float) ($item->traffic_etv ?? 0);

			// petite formule "log" pour obtenir un score 0..100
			$sRD  = ($rd > 0)  ? min(100, (log10($rd + 1) / log10(6000 + 1)) * 100) : 0;
			$sKW  = ($kw > 0)  ? min(100, (log10($kw + 1) / log10(5000 + 1)) * 100) : 0;
			$sETV = ($etv > 0) ? min(100, (log10($etv + 1) / log10(2000 + 1)) * 100) : 0;

			$raw = ($sRD * 0.55) + ($sKW * 0.25) + ($sETV * 0.20);

			// courbe "Moz-like" (écrase les scores moyens)
			$gamma = 3.4;
			$authority = (int) round(100 * pow(($raw / 100), $gamma));
		}

		
		$rd        = (int) $item->linking_domains;      // ex: 3
		$bl        = (int) $item->inbound_links;        // ex: 3

		// IMPORTANT : trafic = float avec point décimal
		$etv = number_format((float) $item->traffic_etv, 2, '.', '');

		// ✅ 2) Prompt verrouillé
		$prompt = "<<<PROMPT
		
Tu es un expert SEO.

IMPORTANT :
- Le trafic ETV est une valeur décimale mensuelle (ex: 49.46 = environ 49 visites / mois).
- Ne transforme JAMAIS les nombres.

Analyse les données suivantes pour un site e-commerce
et produis un diagnostic clair et professionnel.

Données :
- Autorité du domaine : {$authority} / 100
- Domaines référents : {$rd}
- Backlinks : {$bl}
- Trafic SEO estimé : {$etv} visites / mois
- Type de site : e-commerce

Structure OBLIGATOIRE de la réponse (en HTML) :
- <h3>Analyse actuelle</h3>
- <ul> avec les métriques
- <h3>Faut-il obtenir des backlinks ?</h3>
- <h3>Combien en obtenir</h3>
- <h3>Pages à cibler</h3>
- <h3>Rythme recommandé</h3>
- <h3>Actions concrètes</h3>

Contraintes :
- HTML simple uniquement (h3, p, ul, li, strong)
- Pas de markdown
- Pas de noms d’outils
- Ton clair, professionnel, pédagogique
PROMPT;
	
			";

		// ✅ 3) Génération HTML sécurisée
		$html = $openai->generateHtml($prompt);
		$html = preg_replace('/```html|```/i', '', $html);

		return response()->json([
			'html' => $html
		]);
	}

}
