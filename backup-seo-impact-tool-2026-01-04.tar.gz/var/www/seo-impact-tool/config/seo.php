<?php

return [
    'avg_cpc_eur' => (float) env('SEO_AVG_CPC_EUR', 1.2),
];
